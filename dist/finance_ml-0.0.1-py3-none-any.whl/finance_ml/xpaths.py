XPATHS = {
    "arrow_btn":'//*[@id="nimbus-app"]/section/section/section/article/div[1]/div[1]/div[1]/button',
    "max_btn": '/html/body/div[1]/main/section/section/section/article/div[1]/div[1]/div[1]/div/div/div[2]/section/div[1]/button[8]',
    "done_btn": '/html/body/div[1]/main/section/section/section/article/div[1]/div[1]/div[1]/div/div/div[2]/section/div[3]/button[1]',
    "curr_row": '//*[@id="nimbus-app"]/section/section/section/article/div[1]/div[3]/table/tbody/tr['
}